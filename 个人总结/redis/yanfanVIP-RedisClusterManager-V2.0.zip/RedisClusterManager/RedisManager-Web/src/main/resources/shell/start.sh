#!/bin/sh
java -jar RedisManager-Web-1.0.0-SNAPSHOT.jar --spring.config.location=application.properties