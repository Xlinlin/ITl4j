package org.redis.manager.model.enums;

public enum RedisServerStatus {
	NOT_INSTALL,
	WORKING,
	INSTALL,
	CLUSTER
}
