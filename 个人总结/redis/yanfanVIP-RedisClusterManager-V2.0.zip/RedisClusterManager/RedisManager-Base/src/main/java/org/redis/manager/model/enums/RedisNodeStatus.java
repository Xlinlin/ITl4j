package org.redis.manager.model.enums;

public enum RedisNodeStatus {
	CONNECT,
	DISCONNECT
}
