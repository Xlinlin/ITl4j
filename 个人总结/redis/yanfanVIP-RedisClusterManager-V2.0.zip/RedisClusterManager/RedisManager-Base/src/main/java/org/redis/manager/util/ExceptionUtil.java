package org.redis.manager.util;

public class ExceptionUtil {

}
