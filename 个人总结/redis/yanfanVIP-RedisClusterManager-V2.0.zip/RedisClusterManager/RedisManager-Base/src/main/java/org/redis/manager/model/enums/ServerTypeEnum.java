package org.redis.manager.model.enums;

public enum ServerTypeEnum {
	x64,
	x86;
}
