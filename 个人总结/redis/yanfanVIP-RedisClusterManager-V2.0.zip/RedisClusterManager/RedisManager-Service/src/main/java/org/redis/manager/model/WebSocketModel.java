package org.redis.manager.model;

import java.io.Serializable;

public class WebSocketModel implements Serializable{
	private static final long serialVersionUID = -5231223929725210959L;

}
